package steps;

public class NovoFuncionarioTeste {

}
