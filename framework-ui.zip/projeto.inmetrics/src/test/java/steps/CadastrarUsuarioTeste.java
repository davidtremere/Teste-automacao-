package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.CadastrarUsuarioPage;

public class CadastrarUsuarioTeste {

	CadastrarUsuarioPage cadastrar = new CadastrarUsuarioPage();

	@Given("esteja na tela de cadastro")
	public void estejaNaTelaDeCadastro() throws InterruptedException {

		
		cadastrar.acessarFormularioCadastro();

	}

	@Given("preencher os campos de cadastro")
	public void preencherOsCamposDeCadastro() throws InterruptedException {
		cadastrar.cadastrarUsuario("testeUser15", "teste123", "teste123");
	}

	@When("clicar em cadastrar")
	public void clicarEmCadastrar() {
		cadastrar.confirmarCadastro();

	}

	@Then("cadastro realizado com sucesso")
	public void cadastroRealizadoComSucesso() throws InterruptedException {
		cadastrar.validarMensagem();

	}

}
