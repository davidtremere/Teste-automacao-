package metodos;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.commons.io.FileUtils;

import conexoes.Drivers;

public class Metodos extends Drivers {

	public void clicar(By elemento) {
		try {
			driver.findElement(elemento).click();
		} catch (Exception e) {
			System.err.println("---------- ERRO ao clicar ------------");
		}
	}

	public void validarTexto(By elemento, String textoEsperado) {
		try {
			String textoCapturado = driver.findElement(elemento).getText();
			assertTrue(textoCapturado.equals(textoEsperado));
		} catch (Exception e) {
			System.err.println("--------- Erro ao validar texto-------");
		}
	}

	public void escrever(By elemento, String texto) {
		try {
			driver.findElement(elemento).sendKeys(texto);
		} catch (Exception e) {
			System.err.println("---------- ERRO ao escrever ------------");
		}
	}

	public void esperarElemento(By elemento) {
		try {

			WebElement element = new WebDriverWait(driver, Duration.ofSeconds(10))
					.until(ExpectedConditions.elementToBeClickable(elemento));

		} catch (Exception e) {
			System.err.println("---------- ERRO ao esperar elemento ------------");
		}
	}

	public void tirarScreenShot(String nomeEvidencia) {
		try {
			TakesScreenshot scrShot = (TakesScreenshot) driver;
			File scrFile = scrShot.getScreenshotAs(OutputType.FILE);
			File destFile = new File("./evidencias/" + nomeEvidencia + ".png");
			FileUtils.copyFile(scrFile, destFile);
		} catch (Exception e) {
			System.err.println("---------- ERRO ao tirar foto ------------");
		}
	}

}
