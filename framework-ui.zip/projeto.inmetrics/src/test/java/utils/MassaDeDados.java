package utils;

import org.apache.commons.lang3.RandomStringUtils;

public class MassaDeDados {

	public static void main(String[] args) {

		String generatedString = RandomStringUtils.randomAlphabetic(4);
		System.out.println("Jordan" + generatedString);
	}

}
