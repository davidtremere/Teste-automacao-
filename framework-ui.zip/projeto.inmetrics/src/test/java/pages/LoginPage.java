package pages;

import elementos.ElementosWeb;
import metodos.Metodos;

public class LoginPage {

	Metodos metodos = new Metodos();
	ElementosWeb el = new ElementosWeb();

	public void login(String usuario, String senha) {
		metodos.escrever(el.usuario, usuario);
		metodos.escrever(el.senha, senha);

	}

}
