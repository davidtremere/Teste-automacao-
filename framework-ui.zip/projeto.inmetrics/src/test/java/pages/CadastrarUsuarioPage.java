package pages;

import org.openqa.selenium.By;

import elementos.ElementosWeb;
import metodos.Metodos;

public class CadastrarUsuarioPage {

	Metodos metodos = new Metodos();
	ElementosWeb el = new ElementosWeb();

	
	By confirmaSenha = By.name("confirmpass");
	By btnCadastrar = By.xpath("//*[contains(text(), 'Cadastrar')]");
	By btnCadastra_se = By.xpath("//*[@class='w-full text-center p-t-30']//a[contains(text(),'Cadastre-se')]");
	By login = By.xpath("//span[contains(text(),'Login')]");

	public void acessarFormularioCadastro() {
		metodos.clicar(btnCadastra_se);
	}

	/**
	 * Metodo para cadastrar um novo usuario
	 * 
	 * @param usuario
	 * @param senha
	 * @param confirmaSenha
	 * @throws InterruptedException
	 */
	public void cadastrarUsuario(String usuario, String senha, String confirmaSenha) throws InterruptedException {
		metodos.escrever(el.usuario, usuario);
		metodos.escrever(el.senha, senha);
		metodos.escrever(this.confirmaSenha, confirmaSenha);
	}

	public void confirmarCadastro() {
		metodos.clicar(btnCadastrar);

	}

	public void validarMensagem() {
		metodos.validarTexto(login, "Login");
	}

}
