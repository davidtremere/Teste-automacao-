package pages;

import elementos.ElementosWeb;
import metodos.Metodos;

public class AdministrarFuncionariosPage {

	Metodos metodos = new Metodos();
	ElementosWeb el = new ElementosWeb();
	
	public void alterarCadastroDeFuncionario() {
		
	}
	
}
