package pages;

public class NovoFuncionarioPage {

}
