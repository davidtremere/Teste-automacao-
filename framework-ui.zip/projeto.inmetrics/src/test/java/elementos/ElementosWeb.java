package elementos;

import org.openqa.selenium.By;

public class ElementosWeb {

	public By usuario = By.name("username");
	public By senha = By.name("pass");

}
