package conexoes;

import org.openqa.selenium.WebDriver;

public class Drivers {

	public static WebDriver driver;

	
}
