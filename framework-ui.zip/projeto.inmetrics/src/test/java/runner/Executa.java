package runner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.chrome.ChromeDriver;
import conexoes.Drivers;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/resources/",
		glue = "steps",
		tags = "@todos",
		monochrome = true,
		dryRun = true,
		plugin = {"pretty", "html:target/cucumber-report.html" },
		snippets = SnippetType.CAMELCASE)
   
public class Executa extends Drivers {

	@BeforeClass
	public static void abrirNavegador() {	
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://inm-test-app.herokuapp.com/accounts/login/");
		driver.manage().timeouts().getPageLoadTimeout();
		System.out.println("----------------- TESTE INICIADO -------------------");
	}

	@AfterClass
	public static void fecharNavegador() {
		driver.quit();
		System.out.println("--------------- TESTE FINALIZADO --------------------");
	}

}
